#include<bits/stdc++.h>
using namespace std;
int main() {

    for(int i =0 ; i < 10 ; i++ ) {
        cout<<i<<endl;
        string s;
        cin>>s;
        cerr<<s<<endl;
    }
    return 0;
}