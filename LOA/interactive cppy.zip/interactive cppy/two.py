for i in range(10 , 20):
    val = int(input())
    if val % 2 :
        print("odd")
    else:
        print("even")
    
